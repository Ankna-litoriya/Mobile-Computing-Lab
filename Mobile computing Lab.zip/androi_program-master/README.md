# This are the Android program's which are developed by me [sourabh karmakar] during my android lab sestion's, if you find it interesting leave a <3

<img src="assets/gifs/pikachu-loader.gif">

## what will you find here.
### different kind of basic android program for getting started with android.

- PROGRAM-1 <br> 
Develop an android app which displays “Hello, welcome to Android Lab” Toast message
when user click on button. <br><br>
- PROGRAM-2<br>
Develop an android app which displays a form to get following information from user.<br>
Username<br>
Password<br>
Email Address<br>
Phone Number<br>
Country<br>
State<br>
Gender<br>
Interests<br>
Birth Date<br>
Birth Time<br>
Form should be followed by a Button with label “Submit”. When user clicks the button, a
message should be displayed to user describing the information entered. <br><br>

<img scr="assets/svg/screenshot.svg" height="50px">

# Screenshots
<table>
	<tr>
		<td>
			<img src="assets/Screenshots/dashboard.png" height="450px">	
		</td>
		<td>
			<img src="assets/Screenshots/pro1.png" height="450px">			
		</td>
		<td>
			<img src="assets/Screenshots/pro2.png" height="450px">			
		</td>
	</tr>
	<tr>
		<td>
			<img src="assets/Screenshots/pro2_details.png" height="450px">			
		</td>
		<td>
			<img src="assets/Screenshots/pro3(1).png" height="450px">			
		</td>
		<td>
			<img src="assets/Screenshots/pro3(2).png" height="450px">			
		</td>
	</tr>
</table>

<img src="https://media.giphy.com/media/l3q2FnW3yZRJVZH2g/giphy.gif" height="500px">


This Thank you gif you will find in the link below and also get other's
<a href="https://gph.is/2lDKqsX">Thank you - GIPHY</a>
